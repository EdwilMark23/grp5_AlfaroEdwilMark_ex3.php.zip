<?php
print_r(file("file()function.txt"));
?>